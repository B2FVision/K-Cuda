#pragma once
#include "Int.h"

double CalcPercantage(Int val, Int start, Int range);


